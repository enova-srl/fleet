This module extends the Fleet module allowing the registration of vehicle entry and exit inspections.
