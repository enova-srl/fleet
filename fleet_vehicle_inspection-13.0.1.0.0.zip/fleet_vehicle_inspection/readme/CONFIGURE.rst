To configure this module, you will need to set up inspection items for vehicle inspections.

#. Go to Fleet > Configuration > Inspection Items
#. Create or edit inspection items
